
package provaparcial;
/*bibliotecas utilizadas para desenvolvimento do programa,para ajustar a data
(localdate),para criar as listas(arraylist e list),e para criar a area de 
interação (joptionpane)
*/
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class Programa {
    public static void main (String[]args){
        String opçoes;
        String aux;
        String resposta="S";
        
        //declaraçao das listas 
        List <Usuario> usuarios=new ArrayList<>();
        List <Livros> livro=new ArrayList<>();
        List <Emprestimos> emprestimo=new ArrayList<>();
        while(resposta.equals("S")){
            //area de interação
            opçoes=JOptionPane.showInputDialog("OPEÇÕES!!! \n 1-Adicionar usuário \n "
                    + "2-Consultar usuário \n 3-Listar usuários \n 4-Adicionar livro \n "
                    + "5-Consultar livro \n 6-Listar livros \n 7-Realizar emprestimo \n "
                    + "8-Livros emprestados \n 9-Livros devolvidos \n 10-Sair ");
            int resp=Integer.parseInt(opçoes);
            switch(resp){
                //caso queira adicionar um usuario
                case 1:{
                    String nome = null;
                    String email = null;
                    String senha = null;
                    int idu=0;
                    int y=0;
                    aux=JOptionPane.showInputDialog("ID:");
                    idu=Integer.parseInt(aux);
                    //verificar se o usuario ja foi cadastrado
                    for (Usuario usuarios1 : usuarios) {
                         if(usuarios1.getId()==(idu)){
                             System.out.println("ID ja cadastrado!!! \n ");
                            y++;
                         }
                    }
                    if(y==0){
                             nome=JOptionPane.showInputDialog("Nome:");
                             email=JOptionPane.showInputDialog("Email:");
                             senha=JOptionPane.showInputDialog("Senha:");

                            usuarios.add(new Usuario(idu,nome,email,senha));
                    }
                    break;
                }
                //caso queira consultar um usuario
                case 2:{
                    String nome_c;
                    int i=0;
                    nome_c=JOptionPane.showInputDialog("Consultar usuário:");
                    
                     for (Usuario usuarios1 : usuarios) {
                         if(usuarios1.getNome().equals(nome_c)){
                             System.out.println(usuarios1);
                             i++;
                         }
                     }
                     if(i==0){
                        JOptionPane.showMessageDialog(null,"Usuário nao encontrado!!!");
                     }
                    break;
                }
                //para listar todos os usuarios cadastrados
                case 3:{
                    for (Usuario usuarios1 : usuarios) {
                        System.out.println(usuarios1);
                    }
                    break;
                }
                //para adicionar um livro ao acervo
                case 4:{
                    int idl=0;
                    String título=null;
                    String autor=null;
                    String edição=null;
                    String editora=null;
                    String cidade=null;
                    int anoPublicação=0;
                    int z=0;
                    
                    aux=JOptionPane.showInputDialog("ID:");
                    idl=Integer.parseInt(aux);
                    aux=null;
                    //verificar se o livro ja esta cadastrado
                    for (Livros livros1 : livro) {
                        if(livros1.getIdl()== (idl)){
                            System.out.println("ID ja cadastrado!!!");
                            z++;
                        }
                    }
                    if(z==0){
                            título=JOptionPane.showInputDialog("Título:");
                            autor=JOptionPane.showInputDialog("Autor:");
                            edição=JOptionPane.showInputDialog("Edição:");
                            editora=JOptionPane.showInputDialog("Editora:");
                            cidade=JOptionPane.showInputDialog("Cidade:");
                            aux=JOptionPane.showInputDialog("Ano da publicação:");
                            anoPublicação=Integer.parseInt(aux);     
                            livro.add(new Livros(idl,título,autor,edição,editora,cidade,anoPublicação));
                        }
                    break;
                }
                //para consultar um livro
                case 5:{
                    int id_c=0;
                    int x=0;
                    String aux1;
                    aux1=JOptionPane.showInputDialog("ID do livro:");
                    id_c=Integer.parseInt(aux1);
                    
                    for (Livros livros1 : livro) {
                        if(livros1.getIdl()== (id_c)){
                            System.out.println(livros1);
                            x++;
                        }
                    }
                    if(x==0){
                        JOptionPane.showMessageDialog(null,"Livro nao encontrado!!!");
                    }
                    break;
                }
                //para listar todos os livros que estao no acervo
                case 6:{
                    for (Livros livros1 : livro) {
                        System.out.println(livros1);
                    }
                    break;
                }
                //para cadastrar um emprestimo
                case 7:{
                    int ide;
                    int idu1;
                    int idl1;
                    int dias;
                    String aux2;
                    int g=0;
                    aux2=JOptionPane.showInputDialog("ID do empretsimo:");
                    ide=Integer.parseInt(aux2);
                    aux2=null;
                    //verificar se o emprestimo ja existi
                    for(Emprestimos emprestado : emprestimo){
                        if(emprestado.getIde()==(ide)){
                            System.out.println("ID ja cadastrado!!!");
                            g++;
                        }
                    }
                    if(g==0){
                        aux2=JOptionPane.showInputDialog("ID do usuario:");
                        idu1=Integer.parseInt(aux2);
                        aux2=null;
                        aux2=JOptionPane.showInputDialog("ID do livro:");
                        idl1=Integer.parseInt(aux2);
                        aux2=null;
                        LocalDate agora=LocalDate.now();
                        aux2=JOptionPane.showInputDialog("Dias de emprestimos:");
                        dias=Integer.parseInt(aux2);
                        LocalDate entrega=agora.plusDays(dias);

                        emprestimo.add(new Emprestimos(ide,idu1,idl1,agora,entrega,false));
                    }
                    break;
                }
                //para imprimir os livros que nao foram devolvidos
                case 8:{
                     for(Emprestimos emprestado : emprestimo){
                         for(Livros livros1 : livro){
                             if(emprestado.getIdl()== livros1.getIdl()){
                                 System.out.println(livros1);
                             }
                         }
                     }
                    break;
                }
                //para imprimir os livros que foram devolvidos
                case 9:{
                    for(Livros livros1 : livro){
                        for(Emprestimos emprestado : emprestimo){
                            if(livros1.getIdl() == emprestado.getIdl()){
                            }
                            else{
                                System.out.println(livros1);
                            }
                        }
                    }
                    break;
                }
                case 10:{
                    resposta="T";
                    break;
                }
                default:{
                    JOptionPane.showMessageDialog(null,"OPÇÃO INVÁLIDA!!!");
                }
            }
        }
    }
}
