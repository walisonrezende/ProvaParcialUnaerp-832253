
package provaparcial;

import java.time.LocalDate;

/*metodo emprestimo, onde e feito todas as modificaçoes e passagens para os 
emprestimos salvos*/
public class Emprestimos {
     //declaracao dos parametros pertencentes a classe emprestimos
    private int ide;
    private int idu;
    private int idl;
    private LocalDate dataEmprestimo; 
    private LocalDate dataDevolução; 
    private boolean devolução; 

    public Emprestimos() {
    }

    public Emprestimos(int ide, int idu, int idl, LocalDate dataEmprestimo, LocalDate dataDevolução, boolean devolução) {
        this.ide = ide;
        this.idu = idu;
        this.idl = idl;
        this.dataEmprestimo = dataEmprestimo;
        this.dataDevolução = dataDevolução;
        this.devolução = devolução;
    }
    /*Utilizamos os metodos get e set para podermos retornar um valor, no caso 
    os metodos get, e para modificarmos a variavel, no caso os metodos set*/

    public int getIde() {
        return ide;
    }

    public void setIde(int ide) {
        this.ide = ide;
    }

    public int getIdu() {
        return idu;
    }

    public void setIdu(int idu) {
        this.idu = idu;
    }

    public int getIdl() {
        return idl;
    }

    public void setIdl(int idl) {
        this.idl = idl;
    }

    public LocalDate getDataEmprestimo() {
        return dataEmprestimo;
    }

    public void setDataEmprestimo(LocalDate dataEmprestimo) {
        this.dataEmprestimo = dataEmprestimo;
    }

    public LocalDate getDataDevolução() {
        return dataDevolução;
    }

    public void setDataDevolução(LocalDate dataDevolução) {
        this.dataDevolução = dataDevolução;
    }

    public boolean isDevolução() {
        return devolução;
    }

    public void setDevolução(boolean devolução) {
        this.devolução = devolução;
    }
    
    //determinando a forma como retornara os resultados
    @Override
    public String toString() {
        return "ID do emprestimo..:"+getIde()+"\n"+
               "ID do usuario.....:"+getIdu()+"\n"+
               "ID do livro.......:"+getIdl()+"\n"+
               "Data do emprestimo:"+getDataEmprestimo()+"\n"+
               "Data da devolução.:"+getDataDevolução()+"\n"+
               "Devolvido.........:"+isDevolução()+"\n";
    }
}
