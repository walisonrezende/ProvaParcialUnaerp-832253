
package provaparcial;
/*metodo usuario, onde e feito todas as modificaçoes e passagens para os 
usuarios salvos*/
public class Usuario  {
    //declaracao dos parametros pertencentes a classe usuario
    private int id;
    private String nome;
    private String email;
    private String senha;

    public Usuario() {
    }
    
    public Usuario(int id,String nome, String email, String senha) {
        this.id=id;
        this.nome = nome;
        this.email = email;
        this.senha = senha;
    }

    /*Utilizamos os metodos get e set para podermos retornar um valor, no caso 
    os metodos get, e para modificarmos a variavel, no caso os metodos set*/
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    //determinando a forma como retornara os resultados
    @Override
    public String toString() {
        return "ID do usuario:"+getId()+"\n"+
               "Nome.........:"+getNome()+"\n"+
               "Email........:"+getEmail()+"\n"+
               "Senha........:"+getSenha()+"\n";
    }
}
