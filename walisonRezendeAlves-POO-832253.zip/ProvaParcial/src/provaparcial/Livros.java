
package provaparcial;
/*metodo livros, onde e feito todas as modificaçoes e passagens para os 
livros salvos*/
public class Livros {
    //declaracao dos parametros pertencentes a classe livros
    private int idl;
    private String título;
    private String autor;
    private String edição;
    private String editora;
    private String cidade;
    private int anoPublicação;

    public Livros() {
    }

    public Livros(int idl,String título, String autor, String edição, 
            String editora, String cidade, int anopublicação) { 
        this.idl=idl;
        this.título = título;
        this.autor = autor;
        this.edição = edição;
        this.editora = editora;
        this.cidade = cidade;
        this.anoPublicação = anopublicação;
    }
    /*Utilizamos os metodos get e set para podermos retornar um valor, no caso 
    os metodos get, e para modificarmos a variavel, no caso os metodos set*/
    public int getIdl() {
        return idl;
    }

    public void setIdl(int idl) {
        this.idl = idl;
    }
    
    
    public String getTítulo() {
        return título;
    }

    public void setTítulo(String título) {
        this.título = título;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getEdição() {
        return edição;
    }

    public void setEdição(String edição) {
        this.edição = edição;
    }

    public String getEditora() {
        return editora;
    }

    public void setEditora(String editora) {
        this.editora = editora;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public int getAnoPublicação() {
        return anoPublicação;
    }

    public void setAnoPublicação(int anopublicação) {
        this.anoPublicação = anopublicação;
    }
    
    //determinando a forma como retornara os resultados
    @Override
    public String toString() {
        return "ID do livro......:"+getIdl()+"\n"+
               "Título...........:"+getTítulo()+"\n"+ 
               "Autor............:"+getAutor()+"\n"+ 
               "Ediação..........:"+getEdição()+"\n"+
               "Editora..........:"+getEditora()+"\n"+
               "Cidade...........:"+getCidade()+"\n"+
               "Ano da publicação:"+getAnoPublicação()+"\n";
    }
}
